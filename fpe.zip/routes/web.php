<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;

// Definición de Rutas asignándoles un nombre único ->name(...)
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/nosotros', [HomeController::class, 'nosotros'])->name('nosotros');
Route::get('/contacto', [HomeController::class, 'contacto'])->name('contacto');
