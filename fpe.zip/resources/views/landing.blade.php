@extends('layouts.app')

@section('title', 'Fundación Pasos de Esperanza | Transformando Futuros')

@section('content')
    <section class="relative overflow-hidden bg-[linear-gradient(135deg,#fbfcfa_0%,#eef7f7_100%)] py-16 sm:py-20 lg:py-24">
        <div class="absolute inset-0 opacity-70" style="background-image: radial-gradient(circle at 82% 18%, rgba(241,211,110,0.32) 0, transparent 20%), radial-gradient(circle at 12% 78%, rgba(143,198,204,0.28) 0, transparent 26%), radial-gradient(circle at 92% 88%, rgba(183,203,119,0.18) 0, transparent 20%);"></div>
        <div class="relative mx-auto grid max-w-7xl grid-cols-1 items-center gap-12 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
            <div class="max-w-2xl">
                <div class="mb-5 inline-flex items-center gap-2 rounded-full border border-[#8fc6cc]/50 bg-white/80 px-3.5 py-1.5 text-xs font-bold uppercase tracking-[0.14em] text-[#5f7f87] shadow-sm">
                    <span class="h-1.5 w-1.5 rounded-full bg-[#f1d36e]"></span> Comunidad que acompaña
                </div>
                <h1 class="text-4xl font-extrabold leading-[1.1] tracking-tight text-[#2e5a63] sm:text-5xl lg:text-[3.45rem]">
                    Construimos oportunidades con cercanía, educación y esperanza.
                </h1>
                <p class="mt-6 max-w-xl text-lg leading-relaxed text-[#56737b]">
                    Acompañamos a niños y familias con apoyo pedagógico, organización comunitaria y espacios seguros para crecer con más tranquilidad.
                </p>
                <div class="mt-8 flex flex-col gap-3 sm:flex-row">
                    <a href="{{ route('contacto') }}" class="rounded-lg bg-[#f1d36e] px-6 py-3.5 text-center text-sm font-extrabold text-[#2e5a63] shadow-lg shadow-[#d3e6e7]/50 transition hover:bg-[#f4dd8e]">
                        Sé parte del cambio
                    </a>
                    <a href="#pilares" class="rounded-lg border border-[#8fc6cc]/60 px-6 py-3.5 text-center text-sm font-bold text-[#2e5a63] transition hover:bg-white/70">
                        Conoce nuestros programas
                    </a>
                </div>
            </div>
            <div class="rounded-[2rem] border border-[#d8e8e9] bg-white/80 p-6 shadow-xl shadow-[#c7dede]/40 backdrop-blur">
                <p class="text-sm font-bold uppercase tracking-[0.18em] text-[#b7cb77]">Nuestro propósito</p>
                <p class="mt-4 text-2xl font-semibold leading-relaxed text-[#2e5a63] sm:text-3xl">
                    “Que el contexto de un niño nunca defina el alcance de sus sueños.”
                </p>
                <div class="mt-8 grid gap-4 sm:grid-cols-2">
                    <div class="rounded-2xl bg-[#f4faf9] p-4">
                        <p class="text-xs font-bold uppercase tracking-[0.16em] text-[#7b9fa6]">Acompañamiento</p>
                        <p class="mt-2 text-sm leading-relaxed text-[#56737b]">Presencia constante para sostener procesos de aprendizaje y bienestar.</p>
                    </div>
                    <div class="rounded-2xl bg-[#fff9ee] p-4">
                        <p class="text-xs font-bold uppercase tracking-[0.16em] text-[#c79f52]">Red de apoyo</p>
                        <p class="mt-2 text-sm leading-relaxed text-[#56737b]">Aliados, familias y voluntariado trabajando en una misma dirección.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section aria-label="Historias de nuestra comunidad" class="bg-[#fbfcfa] py-14 sm:py-20">
        <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div class="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
                <div>
                    <p class="text-xs font-bold uppercase tracking-[0.16em] text-[#b7cb77]">Nuestra comunidad</p>
                    <h2 class="mt-2 text-3xl font-extrabold tracking-tight text-[#2e5a63] sm:text-4xl">Pequeños pasos, grandes historias</h2>
                </div>
                <p class="max-w-md text-sm leading-relaxed text-[#617980]">Cada actividad abre una posibilidad: aprender, compartir y crecer acompañados.</p>
            </div>

            <div class="group relative overflow-hidden rounded-[2rem] border border-[#d8e8e9] bg-white shadow-xl shadow-[#d3e5e5]/50" data-carousel>
                <div class="relative aspect-[4/3] overflow-hidden sm:aspect-[16/8] lg:aspect-[2.35/1]">
                    <article class="absolute inset-0 opacity-100 transition-opacity duration-700 ease-out" data-slide aria-hidden="false">
                        <img src="https://images.unsplash.com/photo-1497486751825-1233686d5d80?auto=format&amp;fit=crop&amp;w=1800&amp;q=85" alt="Estudiantes participando en una clase" class="h-full w-full object-cover" loading="eager">
                        <div class="absolute inset-0 bg-gradient-to-r from-[#234f57]/92 via-[#234f57]/48 to-transparent"></div>
                        <div class="absolute inset-x-0 bottom-0 p-7 text-white sm:p-10">
                            <p class="text-xs font-bold uppercase tracking-[0.15em] text-[#f1d36e]">Educación que acompaña</p>
                            <h3 class="mt-2 max-w-xl text-2xl font-extrabold sm:text-3xl">Aprender con confianza abre nuevos caminos.</h3>
                        </div>
                    </article>
                    <article class="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-700 ease-out" data-slide aria-hidden="true">
                        <img src="https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&amp;fit=crop&amp;w=1800&amp;q=85" alt="Docente acompañando a un grupo de estudiantes" class="h-full w-full object-cover" loading="lazy">
                        <div class="absolute inset-0 bg-gradient-to-r from-[#234f57]/92 via-[#234f57]/48 to-transparent"></div>
                        <div class="absolute inset-x-0 bottom-0 p-7 text-white sm:p-10">
                            <p class="text-xs font-bold uppercase tracking-[0.15em] text-[#f1d36e]">Presencia y cercanía</p>
                            <h3 class="mt-2 max-w-xl text-2xl font-extrabold sm:text-3xl">Una red de apoyo para avanzar juntos.</h3>
                        </div>
                    </article>
                    <article class="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-700 ease-out" data-slide aria-hidden="true">
                        <img src="https://images.unsplash.com/photo-1502082553048-f009c37129b9?auto=format&amp;fit=crop&amp;w=1800&amp;q=85" alt="Niños compartiendo una actividad al aire libre" class="h-full w-full object-cover" loading="lazy">
                        <div class="absolute inset-0 bg-gradient-to-r from-[#234f57]/92 via-[#234f57]/48 to-transparent"></div>
                        <div class="absolute inset-x-0 bottom-0 p-7 text-white sm:p-10">
                            <p class="text-xs font-bold uppercase tracking-[0.15em] text-[#f1d36e]">Comunidad que cuida</p>
                            <h3 class="mt-2 max-w-xl text-2xl font-extrabold sm:text-3xl">Espacios para descubrir, compartir y crecer.</h3>
                        </div>
                    </article>
                </div>
                <div class="absolute right-4 top-4 flex gap-2 sm:right-6 sm:top-6">
                    <button type="button" class="flex h-10 w-10 items-center justify-center rounded-full bg-white/95 text-[#2e5a63] shadow-sm transition hover:bg-[#f1d36e]" aria-label="Imagen anterior" data-carousel-prev>←</button>
                    <button type="button" class="flex h-10 w-10 items-center justify-center rounded-full bg-white/95 text-[#2e5a63] shadow-sm transition hover:bg-[#f1d36e]" aria-label="Imagen siguiente" data-carousel-next>→</button>
                </div>
                <div class="absolute bottom-4 right-5 flex gap-2 sm:bottom-6 sm:right-7" role="tablist" aria-label="Seleccionar imagen">
                    <button class="h-2.5 w-7 rounded-full bg-[#f1d36e] transition" type="button" aria-label="Ver imagen 1" aria-selected="true" data-carousel-dot></button>
                    <button class="h-2.5 w-2.5 rounded-full bg-[#8fc6cc]/70 transition" type="button" aria-label="Ver imagen 2" aria-selected="false" data-carousel-dot></button>
                    <button class="h-2.5 w-2.5 rounded-full bg-[#8fc6cc]/70 transition" type="button" aria-label="Ver imagen 3" aria-selected="false" data-carousel-dot></button>
                </div>
            </div>
        </div>
    </section>

    <section id="impacto" class="border-y border-[#d8e8e9] bg-[#f3faf9] py-10 sm:py-12">
        <div class="mx-auto grid max-w-7xl grid-cols-2 divide-x divide-[#d8e8e9] px-4 sm:px-6 md:grid-cols-4 lg:px-8">
            <div class="px-4 py-3 text-center">
                <p class="text-xl font-extrabold text-[#2e5a63] sm:text-2xl">Refuerzo</p>
                <p class="mt-1 text-[10px] font-bold uppercase tracking-wider text-[#7b9fa6]">Educativo continuo</p>
            </div>
            <div class="px-4 py-3 text-center">
                <p class="text-xl font-extrabold text-[#2e5a63] sm:text-2xl">Logística</p>
                <p class="mt-1 text-[10px] font-bold uppercase tracking-wider text-[#7b9fa6]">Que conecta</p>
            </div>
            <div class="border-t border-[#d8e8e9] px-4 py-3 text-center md:border-t-0">
                <p class="text-xl font-extrabold text-[#2e5a63] sm:text-2xl">Familias</p>
                <p class="mt-1 text-[10px] font-bold uppercase tracking-wider text-[#7b9fa6]">Más fortalecidas</p>
            </div>
            <div class="border-t border-[#d8e8e9] px-4 py-3 text-center md:border-t-0">
                <p class="text-xl font-extrabold text-[#2e5a63] sm:text-2xl">Gestión</p>
                <p class="mt-1 text-[10px] font-bold uppercase tracking-wider text-[#7b9fa6]">Transparente</p>
            </div>
        </div>
    </section>

    <section id="pilares" class="bg-[#fbfcfa] py-16 sm:py-20">
        <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div class="max-w-2xl">
                <p class="text-xs font-bold uppercase tracking-[0.16em] text-[#b7cb77]">Lo que hacemos</p>
                <h2 class="mt-2 text-3xl font-extrabold tracking-tight text-[#2e5a63] sm:text-4xl">Programas con propósito</h2>
                <p class="mt-4 leading-relaxed text-[#617980]">Convertimos necesidades concretas en acompañamiento constante, cercano y humano.</p>
            </div>
            <div class="mt-10 grid grid-cols-1 gap-5 md:grid-cols-3">
                <article class="border border-[#d8e8e9] bg-white p-7 shadow-sm">
                    <div class="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#eef7f7] text-xl">📚</div>
                    <h3 class="mt-5 text-xl font-extrabold text-[#2e5a63]">Refuerzo escolar</h3>
                    <p class="mt-3 text-sm leading-relaxed text-[#617980]">Apoyo pedagógico para fortalecer la lectura, el aprendizaje y la autonomía en las tareas.</p>
                </article>
                <article class="border border-[#d8e8e9] bg-white p-7 shadow-sm">
                    <div class="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#fff8e8] text-xl">🚌</div>
                    <h3 class="mt-5 text-xl font-extrabold text-[#2e5a63]">Soporte y transporte</h3>
                    <p class="mt-3 text-sm leading-relaxed text-[#617980]">Coordinamos soluciones de movilidad para que cada estudiante llegue seguro a sus actividades.</p>
                </article>
                <article class="border border-[#d8e8e9] bg-white p-7 shadow-sm">
                    <div class="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#f2f8e9] text-xl">🌱</div>
                    <h3 class="mt-5 text-xl font-extrabold text-[#2e5a63]">Acompañamiento familiar</h3>
                    <p class="mt-3 text-sm leading-relaxed text-[#617980]">Talleres y espacios de encuentro que fortalecen los vínculos y las herramientas de cada familia.</p>
                </article>
            </div>
        </div>
    </section>

    <section id="nosotros" class="bg-white py-16 sm:py-20">
        <div class="mx-auto grid max-w-7xl grid-cols-1 gap-10 px-4 sm:px-6 lg:grid-cols-2 lg:items-center lg:px-8">
            <div class="border-l-4 border-[#f1d36e] pl-6">
                <p class="text-xs font-bold uppercase tracking-[0.16em] text-[#b7cb77]">Quiénes somos</p>
                <h2 class="mt-2 text-3xl font-extrabold tracking-tight text-[#2e5a63] sm:text-4xl">Una fundación que trabaja desde la cercanía.</h2>
            </div>
            <p class="leading-relaxed text-[#617980]">
                Creemos en el poder de una comunidad que se organiza para cuidar. Por eso articulamos voluntariado, familias y aliados alrededor de oportunidades reales para la niñez.
            </p>
        </div>
    </section>

    <section class="bg-[#2e5a63] py-16 text-white">
        <div class="mx-auto max-w-4xl px-4 text-center sm:px-6">
            <p class="text-xs font-bold uppercase tracking-[0.16em] text-[#f1d36e]">Tu participación importa</p>
            <h2 class="mt-3 text-3xl font-extrabold sm:text-4xl">Súmate a una red que hace la diferencia.</h2>
            <p class="mx-auto mt-4 max-w-2xl leading-relaxed text-white/75">
                Como voluntario, aliado o donante, puedes ayudar a que más niños encuentren apoyo y posibilidades.
            </p>
            <a href="{{ route('contacto') }}" class="mt-8 inline-block rounded-lg bg-[#f1d36e] px-7 py-3.5 text-sm font-extrabold text-[#2e5a63] transition hover:bg-[#f4dd8e]">
                Ponte en contacto
            </a>
        </div>
    </section>
@endsection

@push('scripts')
    <script>
        document.querySelectorAll('[data-carousel]').forEach((carousel) => {
            const slides = [...carousel.querySelectorAll('[data-slide]')];
            const dots = [...carousel.querySelectorAll('[data-carousel-dot]')];
            let active = 0;
            let timer;

            const showSlide = (next) => {
                active = (next + slides.length) % slides.length;
                slides.forEach((slide, index) => {
                    const isActive = index === active;
                    slide.classList.toggle('opacity-100', isActive);
                    slide.classList.toggle('opacity-0', !isActive);
                    slide.classList.toggle('pointer-events-none', !isActive);
                    slide.setAttribute('aria-hidden', !isActive);
                    dots[index].className = `rounded-full transition ${isActive ? 'h-2.5 w-7 bg-[#f1d36e]' : 'h-2.5 w-2.5 bg-[#8fc6cc]/70'}`;
                    dots[index].setAttribute('aria-selected', isActive);
                });
            };

            const restart = () => {
                clearInterval(timer);
                timer = setInterval(() => showSlide(active + 1), 6000);
            };

            carousel.querySelector('[data-carousel-prev]').addEventListener('click', () => {
                showSlide(active - 1);
                restart();
            });

            carousel.querySelector('[data-carousel-next]').addEventListener('click', () => {
                showSlide(active + 1);
                restart();
            });

            dots.forEach((dot, index) => dot.addEventListener('click', () => {
                showSlide(index);
                restart();
            }));

            carousel.addEventListener('mouseenter', () => clearInterval(timer));
            carousel.addEventListener('mouseleave', restart);
            restart();
        });
    </script>
@endpush
