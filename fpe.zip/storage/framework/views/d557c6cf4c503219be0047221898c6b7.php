<nav
    data-navbar
    class="sticky top-0 z-50 border-b border-[#d8e8e9]/80 bg-white/90 text-[#2e5a63] shadow-sm backdrop-blur transition-[background-color,border-color,box-shadow] duration-300"
>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex h-[4.75rem] items-center justify-between">
            <a href="<?php echo e(route('home')); ?>" class="group flex items-center gap-3" aria-label="Fundación Pasos de Esperanza, inicio">
                <div class="flex h-12 w-12 items-center justify-center overflow-hidden rounded-full bg-white p-0.5 shadow-sm ring-1 ring-[#cfe5e6]/80 transition group-hover:shadow-md">
                    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo de Pasos de Esperanza" class="h-full w-full object-contain">
                </div>
                <div class="leading-tight">
                    <span class="block text-[0.95rem] font-extrabold tracking-tight text-[#2e5a63]">Pasos de Esperanza</span>
                    <span class="block pt-0.5 text-[10px] font-bold uppercase tracking-[0.14em] text-[#b7cb77]">Fundación</span>
                </div>
            </a>

            <div class="hidden items-center gap-7 text-sm font-semibold text-[#5f7f87] lg:flex">
                <a href="<?php echo e(route('home')); ?>" class="transition hover:text-[#2e5a63]">Inicio</a>
                <a href="#pilares" class="transition hover:text-[#2e5a63]">Programas</a>
                <a href="#impacto" class="transition hover:text-[#2e5a63]">Impacto</a>
                <a href="#nosotros" class="transition hover:text-[#2e5a63]">Nosotros</a>
                <a href="<?php echo e(route('contacto')); ?>" class="rounded-lg bg-[#2e5a63] px-5 py-2.5 font-bold text-white shadow-sm transition hover:bg-[#3f7079] focus:outline-none focus:ring-2 focus:ring-[#f1d36e] focus:ring-offset-2">
                    Contáctanos
                </a>
            </div>

            <button type="button" class="inline-flex items-center justify-center rounded-lg p-2 text-[#2e5a63] transition hover:bg-[#eef6f5] focus:outline-none focus:ring-2 focus:ring-[#f1d36e] lg:hidden" aria-expanded="false" aria-controls="mobile-menu" data-menu-toggle>
                <span class="sr-only">Abrir menú de navegación</span>
                <svg class="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path stroke-linecap="round" d="M4 7h16M4 12h16M4 17h16" /></svg>
            </button>
        </div>
        <div id="mobile-menu" class="hidden border-t border-[#d8e8e9]/70 py-3 lg:hidden" data-mobile-menu>
            <div class="flex flex-col gap-1 text-sm font-semibold text-[#5f7f87]">
                <a href="<?php echo e(route('home')); ?>" class="rounded-lg px-3 py-2.5 hover:bg-[#eef6f5]">Inicio</a>
                <a href="#pilares" class="rounded-lg px-3 py-2.5 hover:bg-[#eef6f5]">Programas</a>
                <a href="#impacto" class="rounded-lg px-3 py-2.5 hover:bg-[#eef6f5]">Impacto</a>
                <a href="#nosotros" class="rounded-lg px-3 py-2.5 hover:bg-[#eef6f5]">Nosotros</a>
                <a href="<?php echo e(route('contacto')); ?>" class="mt-1 rounded-lg bg-[#2e5a63] px-3 py-2.5 text-center font-bold text-white">Contáctanos</a>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH /home/faviosantos/Documents/Workspace/Laravel/fpe/resources/views/partials/navbar.blade.php ENDPATH**/ ?>