<!DOCTYPE html>
<html lang="es" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Fundación Pasos de Esperanza'); ?></title>
    <!-- CDN de Tailwind CSS con tipografía limpia -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
    </style>
</head>
<body class="bg-[#fbfcfa] text-[#2e5a63] flex flex-col min-h-screen antialiased">

    <!-- Navegación Modular -->
    <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Contenido Principal Dinámico -->
    <main class="flex-grow">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Pie de Página Modular -->
    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const navbar = document.querySelector('[data-navbar]');
            const menuToggle = document.querySelector('[data-menu-toggle]');
            const mobileMenu = document.querySelector('[data-mobile-menu]');

            const setNavbarState = () => {
                if (!navbar) return;

                const scrolled = window.scrollY > 18;
                navbar.classList.toggle('bg-white/75', scrolled);
                navbar.classList.toggle('bg-white/95', !scrolled);
                navbar.classList.toggle('border-slate-200/50', scrolled);
                navbar.classList.toggle('border-slate-200/70', !scrolled);
                navbar.classList.toggle('shadow-md', scrolled);
                navbar.classList.toggle('shadow-sm', !scrolled);
            };

            if (menuToggle && mobileMenu) {
                menuToggle.addEventListener('click', function () {
                    const isOpen = !mobileMenu.classList.toggle('hidden');
                    this.setAttribute('aria-expanded', isOpen);
                });
            }

            setNavbarState();
            window.addEventListener('scroll', setNavbarState, { passive: true });
        });
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/faviosantos/Documents/Workspace/Laravel/fpe/resources/views/layouts/app.blade.php ENDPATH**/ ?>