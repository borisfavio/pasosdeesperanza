<?php $__env->startSection('title', 'Contacto | Fundación Pasos de Esperanza'); ?>

<?php $__env->startSection('content'); ?>
    <section class="relative overflow-hidden bg-[linear-gradient(135deg,#fbfcfa_0%,#eef7f7_100%)] py-16 sm:py-20 lg:py-24">
        <div class="absolute inset-0 opacity-70" style="background-image: radial-gradient(circle at 82% 18%, rgba(241,211,110,0.28) 0, transparent 20%), radial-gradient(circle at 12% 78%, rgba(143,198,204,0.26) 0, transparent 26%);"></div>
        <div class="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div class="max-w-3xl">
                <p class="text-xs font-bold uppercase tracking-[0.16em] text-[#b7cb77]">Contacto</p>
                <h1 class="mt-3 text-4xl font-extrabold tracking-tight text-[#2e5a63] sm:text-5xl">
                    Estamos cerca para escucharte y coordinar contigo.
                </h1>
                <p class="mt-5 max-w-2xl text-lg leading-relaxed text-[#56737b]">
                    Si quieres sumarte como voluntario, hacer una alianza o pedir información, puedes contactarnos directamente por teléfono o correo.
                </p>
            </div>

            <div class="mt-12 grid grid-cols-1 gap-6 lg:grid-cols-3">
                <article class="rounded-[1.5rem] border border-[#d8e8e9] bg-white p-7 shadow-sm">
                    <div class="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#eef7f7] text-2xl">📞</div>
                    <p class="mt-5 text-xs font-bold uppercase tracking-[0.16em] text-[#7b9fa6]">Teléfono</p>
                    <a href="tel:69700259" class="mt-2 block text-2xl font-extrabold text-[#2e5a63]">69700259</a>
                    <p class="mt-3 text-sm leading-relaxed text-[#617980]">Atención directa para coordinación y consultas.</p>
                </article>

                <article class="rounded-[1.5rem] border border-[#d8e8e9] bg-white p-7 shadow-sm">
                    <div class="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#fff8e8] text-2xl">✉️</div>
                    <p class="mt-5 text-xs font-bold uppercase tracking-[0.16em] text-[#c79f52]">Correo</p>
                    <a href="mailto:contacto@fundacionpasosdeesperanza.org.bo" class="mt-2 block break-words text-xl font-extrabold text-[#2e5a63]">
                        contacto@fundacionpasosdeesperanza.org.bo
                    </a>
                    <p class="mt-3 text-sm leading-relaxed text-[#617980]">Escríbenos y te responderemos a la brevedad.</p>
                </article>

                <article class="rounded-[1.5rem] border border-[#d8e8e9] bg-white p-7 shadow-sm">
                    <div class="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#f2f8e9] text-2xl">📍</div>
                    <p class="mt-5 text-xs font-bold uppercase tracking-[0.16em] text-[#b7cb77]">Dirección</p>
                    <p class="mt-2 text-xl font-extrabold text-[#2e5a63]">
                        Zona Alto Santiago de Alcaya, Calle 4 Nro 467
                    </p>
                    <p class="mt-3 text-sm leading-relaxed text-[#617980]">La Paz, Bolivia</p>
                </article>
            </div>

            <div class="mt-10 grid grid-cols-1 gap-6 lg:grid-cols-2">
                <div class="rounded-[2rem] border border-[#d8e8e9] bg-white p-8 shadow-sm">
                    <p class="text-xs font-bold uppercase tracking-[0.16em] text-[#b7cb77]">Horarios</p>
                    <h2 class="mt-3 text-2xl font-extrabold text-[#2e5a63]">Estamos disponibles para coordinar contigo.</h2>
                    <div class="mt-6 space-y-4 text-sm leading-relaxed text-[#617980]">
                        <p><span class="font-bold text-[#2e5a63]">Atención telefónica:</span> según disponibilidad de la fundación.</p>
                        <p><span class="font-bold text-[#2e5a63]">Correo electrónico:</span> respuesta en el menor tiempo posible.</p>
                        <p><span class="font-bold text-[#2e5a63]">Ubicación:</span> Zona Alto Santiago de Alcaya, Calle 4 Nro 467, La Paz, Bolivia.</p>
                    </div>
                    <div class="mt-8 flex flex-col gap-3 sm:flex-row">
                        <a href="tel:69700259" class="rounded-lg bg-[#2e5a63] px-5 py-3 text-center text-sm font-bold text-white transition hover:bg-[#3f7079]">
                            Llamar ahora
                        </a>
                        <a href="mailto:contacto@fundacionpasosdeesperanza.org.bo" class="rounded-lg border border-[#8fc6cc]/60 px-5 py-3 text-center text-sm font-bold text-[#2e5a63] transition hover:bg-[#eef6f5]">
                            Escribir correo
                        </a>
                    </div>
                </div>

                <div class="overflow-hidden rounded-[2rem] border border-[#d8e8e9] bg-[#f4faf9] shadow-sm">
                    <div class="p-8">
                        <p class="text-xs font-bold uppercase tracking-[0.16em] text-[#b7cb77]">Cómo encontrarnos</p>
                        <h2 class="mt-3 text-2xl font-extrabold text-[#2e5a63]">Un punto de encuentro para seguir construyendo juntos.</h2>
                        <p class="mt-4 text-sm leading-relaxed text-[#617980]">
                            Si necesitas coordinar una visita o quieres conocer mejor el trabajo de la fundación, puedes escribirnos o llamarnos y te orientamos.
                        </p>
                    </div>
                    <div class="border-t border-[#d8e8e9] bg-white/80 px-8 py-6">
                        <div class="grid gap-4 sm:grid-cols-2">
                            <div class="rounded-2xl bg-white p-4 shadow-sm">
                                <p class="text-xs font-bold uppercase tracking-[0.16em] text-[#7b9fa6]">Teléfono</p>
                                <p class="mt-2 text-lg font-bold text-[#2e5a63]">69700259</p>
                            </div>
                            <div class="rounded-2xl bg-white p-4 shadow-sm">
                                <p class="text-xs font-bold uppercase tracking-[0.16em] text-[#7b9fa6]">Correo</p>
                                <p class="mt-2 text-sm font-bold text-[#2e5a63]">contacto@fundacionpasosdeesperanza.org.bo</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/faviosantos/Documents/Workspace/Laravel/fpe/resources/views/contacto.blade.php ENDPATH**/ ?>